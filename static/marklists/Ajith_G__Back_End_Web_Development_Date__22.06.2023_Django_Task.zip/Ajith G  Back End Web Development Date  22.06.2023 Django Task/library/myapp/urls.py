from django.urls import path
from . views import WelcomeView,BookListView,AuthorListView
from . import views



urlpatterns = [
    

    path('home/',WelcomeView.as_view(), name='home'),
    path('booklist/',BookListView.as_view(),name='booklist'),
    path('authorlist',AuthorListView.as_view(),name='authorlist'),
    path('booklist/<int:book_id>/',views.book_detail,name='book_detail'),
    path('login/',views.Login, name='login'),
    path('view/',views.BookView,name='view'),
    path('update/<int:book_id>',views.book_update,name='update')
    
  
  
]
