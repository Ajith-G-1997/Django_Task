from django.shortcuts import render,get_object_or_404,redirect
from django.views.generic import TemplateView,ListView
from django.http import HttpResponse
from .models import BookList,Author,Book
from .forms import BookForm



class WelcomeView(TemplateView):
    template_name = 'library/home.html'
    

class BookListView(ListView):
    model = BookList
    template_name = 'library/book_list.html'
    context_object_name = 'booklist'

class AuthorListView(ListView):
    model = Author
    template_name = 'library/authors_list.html'
    context_object_name = 'authors'


def book_detail(request,book_id):
	book_detail=BookList.objects.get(bookid=book_id)
	context={
	'book_detail':book_detail
	}
	return render(request,'library/book_detail.html',context)



def Login(request):
    if request.method == 'POST':
        form = BookForm(request.POST)
        if form.is_valid():
            form.save()  # Save the form data into the database
            # return Httpredirect('library/home.html')  # Redirect to the book list view
            return HttpResponse("<h1>Saved</h1>")
    else:   

        form = BookForm()
    return render(request, 'crud/login.html', {'form': form})


def BookView(request):
    form =Book.objects.all()
    form ={
	    'from':form
	}
    return render(request,'crud/view.html',form)




def book_update(request,bookid):
    
    book = get_object_or_404(Book, bookid=bookid)

    
    if request.method == 'POST':
        form = BookForm(request.POST, instance=book)
        if form.is_valid():
            form.save()
            return redirect('library/book_detail', bookid=bookid)
    else:
        form = BookForm(instance=book)
    return render(request, 'crud/book_update.html', {'form': form, 'book': book})

