from django.contrib import admin
from .models import  Author,Book,Category,Genre,Booking


# Register your models here.


    


class AuthorAdmin(admin.ModelAdmin):
    list_display = ['first_name', 'last_name','email']

admin.site.register(Author, AuthorAdmin)

class BookAdmin(admin.ModelAdmin):
    list_display = [
    'title','author','publication_date',
    'created_date','is_available','price',
    'description','book_code','category','genre','rating'
    ]

admin.site.register(Book, BookAdmin)

class CategoryAdmin(admin.ModelAdmin):
    list_display = ['name',]

admin.site.register(Category, CategoryAdmin)

class GenreAdmin(admin.ModelAdmin):
    list_display = ['name',]

admin.site.register(Genre, GenreAdmin)


class BookingAdmin(admin.ModelAdmin):
    list_display = [
    'title','author','publication_date',
    'created_date','is_available','price',
    'description','book_code','category','genre','rating'
    ]
    
admin.site.register(Booking, BookingAdmin)