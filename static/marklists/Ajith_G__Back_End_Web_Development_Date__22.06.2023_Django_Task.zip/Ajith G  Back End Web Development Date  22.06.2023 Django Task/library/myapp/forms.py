from django import forms
from .models import Book,Booking




class BookForm(forms.ModelForm):
    class Meta:
        model = Book
        fields = '__all__'

      
       
class BookingForm(forms.ModelForm):
    class Meta:
        model = Booking
        fields = '__all__'