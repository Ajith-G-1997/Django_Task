from django.db import models
from django.db import models
from django.db.models import CharField,DateField,BooleanField,TextField,FloatField,IntegerField,EmailField,ForeignKey,ManyToManyField


# Create your models here.
class BookList(models.Model):
    bookid =IntegerField(unique=True)
    title = CharField(max_length=100)
    description =TextField()

    def __str__(self):
        return self.title
    
class Author(models.Model):
    first_name = CharField(max_length=100)
    last_name = CharField(max_length=100)
    email = EmailField(unique=True)

    def __str__(self):
        return self.first_name


class Category(models.Model):
    name=CharField(max_length=255)
    
    def __str__(self):
        return self.name

class Genre(models.Model):
    name=CharField(max_length=255)  
    def __str__(self):
        return self.name  
    
class Book(models.Model):
    bookid=IntegerField(default=True,unique=True)
    title=CharField(max_length=255,null=False)
    author=ForeignKey(Author, on_delete=models.CASCADE)
    publication_date=DateField(null=False)
    created_date=DateField(auto_now_add=True)
    is_available=BooleanField(default=True)
    price=FloatField(null=False)
    description=TextField()
    book_code=IntegerField(unique=True,null=False)
    category=ForeignKey(Category, on_delete=models.CASCADE)
    genre=CharField(max_length=255)
    rating=FloatField()

    def __str__(self):
        return self.title
class Booking(models.Model):
    bookid=IntegerField(default=True,unique=True)
    title=CharField(max_length=255,null=False)
    author=ForeignKey(Author, on_delete=models.CASCADE)
    publication_date=DateField(null=False)
    created_date=DateField(auto_now_add=True)
    is_available=BooleanField(default=True)
    price=FloatField(null=False)
    description=TextField()
    book_code=IntegerField(unique=True,null=False)
    category=ForeignKey(Category, on_delete=models.CASCADE)
    genre=ForeignKey(Genre, on_delete=models.CASCADE)
    rating=FloatField()

    def __str__(self):
        return self.title
